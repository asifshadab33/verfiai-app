# Verfiai free tools and free-websites directory update

This update adds a static `/free-websites` directory and four browser-only utilities:

- `/tools/json-formatter` — format, validate and minify JSON locally.
- `/tools/uuid-generator` — secure UUID v4 generation using browser cryptography.
- `/tools/reference-deduplicator` — deduplicate RIS, BibTeX and plain-text reference lists by DOI/title/normalized line.
- `/tools/identifier-extractor` — extract candidate DOI, ORCID, PMID and ISBN identifiers locally.

The directory at `/free-websites` links directly to independent services for file transfers, academic literature, reference management, writing, public datasets, media licensing, verification, and document utilities. It does not embed third-party tools, proxy requests, accept uploads, or make background API calls.

The Domain Age Checker now uses the IANA RDAP DNS bootstrap list to locate the appropriate registry rather than sending every domain to RIPE. The `.gitignore` now excludes local `.env` files while allowing `.env.example`.

## Privacy and cost profile

- New local utilities run in the visitor's browser; no Verfiai server, AI gateway, database, or API request is required.
- The external directory is static content. A visitor only contacts a third party after selecting its link.
- Existing tools retain their existing network behaviour. In particular, review each tool's privacy notice before using it with confidential material.
- Free tiers, provider limits, privacy terms and availability can change.

## Important deployment note

The source archive supplied for this update contained local environment files. They are intentionally omitted from the delivery ZIPs. Keep production secrets and local environment files in the hosting provider's secret/environment settings, not in a public ZIP or Git commit. `.env.example` is retained as a template.

## Validation status

Source and route/search-index/sitemap consistency were inspected. TypeScript/TSX syntax transpilation and static route/search-index/sitemap checks passed. A full type-check, lint run, test suite and production build could not be completed: dependency installation timed out in this environment. Run `npm ci`, `npm run lint`, `npm test`, and `npm run build` in the project's normal development environment before deployment.

## Additional code-review observations

- The existing QR generator contacts the external QR Server service with the text or URL entered. This does not use Verfiai's server, but the input leaves the visitor's browser; avoid entering confidential content. A future local QR encoder would improve privacy.
- The link-expander tool depends on the target website allowing browser cross-origin requests. Many sites block this; the no-proxy policy means some links cannot be expanded in-browser.
- The Markdown preview escapes user-provided HTML before rendering supported Markdown. Existing tests cover common script and image-injection strings.
- The code scan found no `eval()` or `new Function()` usage.
