import { createFileRoute } from "@tanstack/react-router";
import { ContentPage, PageSection } from "@/components/verifai/ContentPage";
export const Route = createFileRoute("/features")({
  head: () => ({
    meta: [
      { title: "Features | Verfiai" },
      {
        name: "description",
        content: "Explore Verfiai's AI research reports and Crossref citation checker.",
      },
      { property: "og:title", content: "Features | Verfiai" },
      {
        property: "og:description",
        content: "Explore AI research reports and Crossref citation checks.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "canonical", href: "https://verfiai.app/features" }],
  }),
  component: Features,
});
function Features() {
  return (
    <ContentPage
      title="Tools for careful research"
      intro="Write a structured AI-assisted brief, then examine references separately against public Crossref records."
    >
      <PageSection title="Professional reports">
        <p>
          Ask a question, add a short text brief and choose a research mode. The report separates
          findings, sources, conflicting evidence, methodology and limitations. AI may make
          mistakes; source URLs are suggestions to check, not verified live references.
        </p>
      </PageSection>
      <PageSection title="Citation checker">
        <p>
          Paste references or read a .docx, .bib, .txt or .md file in your browser. AI identifies
          cited works and Crossref checks for matching records and retraction notices. A missing
          Crossref match is not proof of fabrication.
        </p>
      </PageSection>
      <PageSection title="Languages and exports">
        <p>
          The research workspace offers 19 language choices; the main page text is translated in all
          19, with English shown for anything not yet translated. Reports can be copied, saved as
          Markdown, or printed to PDF. Citation checking currently displays English results.
        </p>
      </PageSection>
    </ContentPage>
  );
}
