import { createFileRoute } from "@tanstack/react-router";
import { ContentPage, PageSection } from "@/components/verifai/ContentPage";
export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How Verfiai works" },
      {
        name: "description",
        content:
          "Learn how AI research reports and citation checks are generated, and where verification remains your responsibility.",
      },
      { property: "og:title", content: "How Verfiai works" },
      {
        property: "og:description",
        content: "From research question to structured report, with evidence and limitations.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "canonical", href: "https://verfiai.app/how-it-works" }],
  }),
  component: How,
});
function How() {
  return (
    <ContentPage
      title="From a question to a clearer picture"
      intro="The report generator and citation checker serve different purposes. Use both with independent judgment."
    >
      <PageSection title="01 / Start with a question">
        <p>
          Describe what you need to know. You may attach a .txt or .md brief up to 200 KB. Optional
          settings narrow the topic and choose an output language.
        </p>
      </PageSection>
      <PageSection title="02 / AI organizes a report">
        <p>
          An AI model writes a summary, findings, source suggestions, disagreements and limitations.
          It does not search the live web. Open every link and confirm dates and claims before
          citing them.
        </p>
      </PageSection>
      <PageSection title="03 / Check your references">
        <p>
          Switch to Citation checker and paste a reference list or upload a supported file. The
          scanner identifies up to 40 citations and looks up Crossref records and retraction
          notices. Crossref coverage is incomplete, so inspect any flagged reference manually.
        </p>
      </PageSection>
      <PageSection title="04 / Take your work with you">
        <p>
          Copy or download the report as Markdown, or print it to a PDF using your browser. Reports
          and scans do not appear in an account history.
        </p>
      </PageSection>
    </ContentPage>
  );
}
