import { createFileRoute } from "@tanstack/react-router";
import { ContentPage, PageSection } from "@/components/verifai/ContentPage";

const title = "Verification Methodology | Verfiai";
const description =
  "How Verfiai finds sources, assesses factual claims and citations, handles model data, and communicates uncertainty and limitations.";

export const Route = createFileRoute("/methodology")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "canonical", href: "https://verfiai.app/methodology" }],
  }),
  component: Methodology,
});

function Methodology() {
  return (
    <ContentPage
      title="Verification methodology"
      intro="Transparency is core to Verfiai. This page explains how the system processes information, evaluates evidence and presents findings. Last updated: October 31, 2026."
    >
      <PageSection title="Research starts only when requested">
        <p>
          Page visits and local directory browsing do not invoke search or AI. Choosing Generate
          report, a claim check or a citation scan starts that request; it is not an automatic
          consequence of visiting. Analytics acceptance is separate and never starts research.
          Research reports require a signed-in free account; claim checks and citation scans remain
          available to signed-out visitors. Existing guest, account and monthly fair-use limits
          still apply. A fresh matching research result is checked before searching or calling
          models.
        </p>
      </PageSection>
      <PageSection title="Repeated requests and unavailable providers">
        <p>
          Research reuse is scoped to the caller, exact request, language and scoring cohort. Rare
          results remain fresh for 24 hours; results used at least three times while fresh qualify
          for seven days from their original creation. When the AI cascade is exhausted, a matching
          cached result up to thirty days old is shown with its date and an older-result notice.
          Without one, available source links are shown without an AI answer or measured verdict.
          Source-only output is not a completed research synthesis and may be shorter than a normal
          report. Other failures, including account limits or saving failures, can still require
          action. Cached evidence can be outdated; always open original sources.
        </p>
      </PageSection>
      <PageSection title="What Verfiai analyzes">
        <p>
          Verfiai analyzes factual claims in submitted text, documents, and research questions. It
          also extracts and checks academic citations. It does not treat opinions, predictions, or
          creative statements as verifiable facts.
        </p>
      </PageSection>
      <PageSection title="How sources are found and selected">
        <p>
          Verfiai currently searches Tavily, GDELT DOC 2.0 news documents, Crossref, English and
          report-language Wikipedia, PubMed, OpenAlex, DuckDuckGo's official Instant Answer service,
          and Wikidata's SPARQL query service for structured reference entries (who, when,
          how-many). Where a Google Fact Check Tools key is configured, results also include
          professional fact-check verdicts from the ClaimReview database — the strongest claim
          signal Verfiai receives, though each verdict remains a judgement by the publishing
          fact-checker. Brave Search, You.com or a SearXNG instance may also be used when
          configured. Stack Exchange, the Internet Archive's Wayback Machine, World Bank Open Data,
          SEC EDGAR and Europe PMC are also queried. Research reports additionally run site-limited
          Tavily searches of Quora and Reddit, used only as low-weight community context that never
          strengthens a verdict, and the document dossier queries OpenAlex and Semantic Scholar.
          Results are deduplicated and ranked using keyword relevance and reciprocal rank fusion.
          Crossref is used for citation records; PubMed adds biomedical literature. GDELT is queried
          through a paced queue (one request at least every 2 seconds, with retries when it is
          busy); if GDELT is slow or unavailable, checks continue without news results. Wikidata
          entries are treated as reference context and never as direct evidence quotes. Paywalled
          full text is not retrieved.
        </p>
      </PageSection>
      <PageSection title="How claims and evidence are assessed">
        <p>
          A cost-aware AI route first extracts claims and evaluates retrieved excerpts. Evaluation
          uses a fallback chain of hosted open and commercial models; free-tier provider leadership
          rotates by minute, with optional low-cost Lovable AI share slots. Paid models and the
          direct Gemini provider remain in the fallback tail rather than leading. Existing provider
          cooldowns and availability checks apply. Which model answered can differ between checks.
          Findings are labelled <strong>Supported</strong>, <strong>Contradicted</strong>,{" "}
          <strong>Mixed evidence</strong>, or <strong>Insufficient evidence</strong> according to
          the evidence returned. If AI evaluation is unavailable, source links alone never establish
          a verdict. This is AI-assisted evaluation, not independent proof.
        </p>
      </PageSection>
      <PageSection title="What “confidence” means">
        <p>
          Evidence strength reflects source quality, diversity and independence, recency,
          directness, and consistency. Several recent independent sources may strengthen a rating;
          sparse, duplicated, outdated, indirect, or conflicting sources weaken it.{" "}
          <strong>Strong evidence does not equal absolute truth.</strong>
        </p>
      </PageSection>
      <PageSection title="Handling disagreement and conflicting evidence">
        <p>
          When credible sources materially disagree, Verfiai flags the finding as{" "}
          <strong>Mixed evidence</strong> and presents supporting and conflicting excerpts where
          available. It does not hide the disagreement or convert it into a definitive verdict.
        </p>
      </PageSection>
      <PageSection title="Citation checks">
        <p>
          Each reference is looked up in Crossref by DOI first. Without a DOI, Verfiai searches
          Crossref and compares titles (Jaro-Winkler similarity), first-author surnames (phonetic
          match) and years (±1). Retraction and withdrawal notices recorded in Crossref are flagged.
          The trust score is 0.4 × record type + 0.25 × recency + 0.2 × citation count − 0.15 ×
          retraction, scaled to 0–100 — an approximate guide, not a quality judgement. "Not found"
          is a prompt to check manually, not proof of fabrication.
        </p>
      </PageSection>
      <PageSection title="Model and data handling">
        <p>
          Submitted text may be processed by AI providers including DeepInfra, Cerebras, SambaNova,
          NVIDIA, Groq, Google Gemini, Mistral, DeepSeek, Alibaba Cloud DashScope, GitHub Models and
          OpenRouter, plus, when enabled, the Lovable AI Gateway using Gemini 2.5 Flash Lite or
          GPT-5 Nano. Lovable is optional, is not free-tier, and has an existing estimated monthly
          spending cap. Search terms and source lookups may be processed by Tavily (including
          site-limited Quora and Reddit searches used only as low-weight community context), Brave
          Search, You.com, a SearXNG instance, GDELT, DuckDuckGo, Wikipedia, Wikidata, Crossref,
          OpenAlex, PubMed, Europe PMC, Semantic Scholar, Stack Exchange, the Internet Archive's
          Wayback Machine, World Bank Open Data, SEC EDGAR and the Google Fact Check Tools API,
          depending on the tool and on which services are configured. Dossier discovery also uses
          Unpaywall for open-access locations and Scribd for metadata on already-found links, not
          paywalled full text. Not every service is contacted on every request. Verfiai does not use
          submissions to train its own models. Third-party retention and training practices are
          governed by each provider's policies, so do not submit confidential, regulated, or
          unpublished material.
        </p>
        <p className="mt-4">
          Provider search and model caches generally use 24-hour freshness, report-generation caches
          seven days and citation lookups thirty days. Repeated caller-scoped research has the
          adaptive reuse and outage window described above. Private verification response freshness
          remains 24 hours. Freshness is not a guarantee of database deletion. Reports are saved to
          the signed-in account that created them and remain until the user deletes them; there are
          no guest reports.
        </p>
      </PageSection>
      <PageSection title="Product limitations">
        <ul className="list-disc space-y-2 pl-5">
          <li>Verfiai cannot read paywalled, offline or non-indexed sources.</li>
          <li>Search coverage may miss very recent events because of indexing delays.</li>
          <li>Source excerpts can omit context found in the full publication.</li>
          <li>AI engines can misinterpret nuanced evidence or context.</li>
          <li>Crossref and other databases do not cover every publication.</li>
          <li>Outputs are decision support, not definitive truth judgments.</li>
        </ul>
      </PageSection>
      <PageSection title="User responsibilities">
        <p>
          Open the source links, review the full context of the excerpts, and apply your own
          professional judgment before making important decisions based on Verfiai results.
        </p>
      </PageSection>
    </ContentPage>
  );
}
