import { createFileRoute } from "@tanstack/react-router";
import { LocalUtilityTools } from "@/components/verifai/tools/LocalUtilityTools";
import { ToolPage } from "@/components/verifai/tools/ToolPage";
import { toolHead } from "@/lib/tools/tool-head";

export const Route = createFileRoute("/tools/uuid-generator")({
  head: () =>
    toolHead({
      path: "/tools/uuid-generator",
      name: "Free UUID Generator",
      title: "Free UUID Generator | Verfiai",
      description: "Generate secure random UUID v4 identifiers locally in your browser. Generate one or a batch of up to 100.",
    }),
  component: Page,
});

function Page() {
  return (
    <ToolPage
      title="Free UUID Generator"
      intro="Generate secure random UUID v4 identifiers locally in your browser. Generate one or a batch of up to 100."
      privacy="This tool runs entirely in your browser. Your input is not uploaded to Verfiai or sent to an external service."
    >
      <LocalUtilityTools slug="uuid-generator" />
    </ToolPage>
  );
}
