import { createFileRoute } from "@tanstack/react-router";
import { LocalUtilityTools } from "@/components/verifai/tools/LocalUtilityTools";
import { ToolPage } from "@/components/verifai/tools/ToolPage";
import { toolHead } from "@/lib/tools/tool-head";

export const Route = createFileRoute("/tools/reference-deduplicator")({
  head: () =>
    toolHead({
      path: "/tools/reference-deduplicator",
      name: "Academic Reference Deduplicator",
      title: "Academic Reference Deduplicator | Verfiai",
      description: "Remove duplicate bibliography entries from RIS, BibTeX or plain-text reference lists using DOI and normalized title matching.",
    }),
  component: Page,
});

function Page() {
  return (
    <ToolPage
      title="Academic Reference Deduplicator"
      intro="Remove duplicate bibliography entries from RIS, BibTeX or plain-text reference lists using DOI and normalized title matching."
      privacy="This tool runs entirely in your browser. Your input is not uploaded to Verfiai or sent to an external service."
    >
      <LocalUtilityTools slug="reference-deduplicator" />
    </ToolPage>
  );
}
