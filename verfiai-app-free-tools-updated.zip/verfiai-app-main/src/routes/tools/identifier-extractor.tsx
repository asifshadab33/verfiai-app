import { createFileRoute } from "@tanstack/react-router";
import { LocalUtilityTools } from "@/components/verifai/tools/LocalUtilityTools";
import { ToolPage } from "@/components/verifai/tools/ToolPage";
import { toolHead } from "@/lib/tools/tool-head";

export const Route = createFileRoute("/tools/identifier-extractor")({
  head: () =>
    toolHead({
      path: "/tools/identifier-extractor",
      name: "Research Identifier Extractor",
      title: "Research Identifier Extractor | Verfiai",
      description: "Extract candidate DOI, ORCID, PMID and ISBN identifiers from pasted text locally in your browser.",
    }),
  component: Page,
});

function Page() {
  return (
    <ToolPage
      title="Research Identifier Extractor"
      intro="Extract candidate DOI, ORCID, PMID and ISBN identifiers from pasted text locally in your browser."
      privacy="This tool runs entirely in your browser. Your input is not uploaded to Verfiai or sent to an external service."
    >
      <LocalUtilityTools slug="identifier-extractor" />
    </ToolPage>
  );
}
