import { createFileRoute } from "@tanstack/react-router";
import { LocalUtilityTools } from "@/components/verifai/tools/LocalUtilityTools";
import { ToolPage } from "@/components/verifai/tools/ToolPage";
import { toolHead } from "@/lib/tools/tool-head";

export const Route = createFileRoute("/tools/json-formatter")({
  head: () =>
    toolHead({
      path: "/tools/json-formatter",
      name: "Free JSON Formatter & Validator",
      title: "Free JSON Formatter & Validator | Verfiai",
      description: "Format, validate and minify JSON directly in your browser. No upload, account or API required.",
    }),
  component: Page,
});

function Page() {
  return (
    <ToolPage
      title="Free JSON Formatter & Validator"
      intro="Format, validate and minify JSON directly in your browser. No upload, account or API required."
      privacy="This tool runs entirely in your browser. Your input is not uploaded to Verfiai or sent to an external service."
    >
      <LocalUtilityTools slug="json-formatter" />
    </ToolPage>
  );
}
