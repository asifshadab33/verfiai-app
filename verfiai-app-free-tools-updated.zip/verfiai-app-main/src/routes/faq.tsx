import { createFileRoute } from "@tanstack/react-router";
import { ContentPage, PageSection } from "@/components/verifai/ContentPage";
import { IS_FREE_Q, IS_FREE_A } from "@/lib/community";
export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "Frequently asked questions | Verfiai" },
      {
        name: "description",
        content:
          "Answers about Verfiai reports, citation checks, files, privacy and current availability.",
      },
      { property: "og:title", content: "Frequently asked questions | Verfiai" },
      {
        property: "og:description",
        content: "Understand Verfiai's report and citation-checking limitations.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "canonical", href: "https://verfiai.app/faq" }],
  }),
  component: FAQ,
});
function FAQ() {
  return (
    <ContentPage title="Frequently asked questions" intro="What to expect from Verfiai today.">
      <PageSection title={IS_FREE_Q}>
        <p>{IS_FREE_A}</p>
      </PageSection>
      <PageSection title="Does the report verify facts on the live web?">
        <p>
          Reports use live web search and AI-assisted evaluation. Search covers web, news, scholarly
          and structured-reference sources (including Wikidata and, where configured, professional
          fact-check verdicts from the Google Fact Check Tools database). Search results and AI
          conclusions can still be wrong, incomplete or outdated. Check each source independently.
        </p>
      </PageSection>
      <PageSection title="How does the citation checker work?">
        <p>
          References are checked against Crossref records and retraction notices. An unmatched
          citation is flagged for manual review, not declared fake. Crossref does not index every
          publication.
        </p>
      </PageSection>
      <PageSection title="Which files can I use?">
        <p>
          Reports accept .txt, .md, .csv, .docx and text-based .pdf files up to 5 MB. Scanned-image
          PDFs cannot be read. Citation checks accept .docx, .bib, .txt or .md up to 5 MB.
        </p>
      </PageSection>
      <PageSection title="Where does my text go?">
        <p>
          Questions and extracted document text are sent to the AI inference providers listed in our
          Privacy Policy; search queries go to the search and data services listed there (such as
          Tavily, Wikipedia, Wikidata, Crossref, OpenAlex and PubMed), and citation details to
          Crossref. Signed-in reports are saved privately until deleted. Do not upload confidential
          material. Provider retention policies may differ.
        </p>
      </PageSection>
      <PageSection title="Is Verfiai free?">
        <p>
          Verfiai is 100% free for everyone for the next year. Sign in with Google or email for the
          current monthly fair-use allowances. Reasonable rate limits protect service availability.
          Contact hello@verfiai.app for academic, educator or high-volume extended access. Paid
          checkout is unavailable.
        </p>
      </PageSection>
    </ContentPage>
  );
}
