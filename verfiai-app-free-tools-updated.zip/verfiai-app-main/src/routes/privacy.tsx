import { createFileRoute, Link } from "@tanstack/react-router";
import { ContentPage, PageSection } from "@/components/verifai/ContentPage";

const title = "Privacy Policy & Data Handling | Verfiai";
const description =
  "How verfiai collects, uses, shares and retains data for Verfiai research and subscriptions.";
export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "canonical", href: "https://verfiai.app/privacy" }],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <ContentPage
      title="Privacy Policy & Data Handling"
      intro="Draft for owner review; not legal advice. Last updated October 31, 2026. verfiai, trading as Verfiai, is the controller of personal data described here. Contact us at hello@verfiai.app."
    >
      <PageSection title="What content is submitted and processed">
        <p>
          Opening a page or browsing the source directory does not start web research or call an AI
          model. Search and AI processing start only when you explicitly submit a research,
          claim-check or citation request; this choice is separate from analytics consent. Submitted
          questions, extracted document text and retrieved excerpts may then be processed by the
          services listed below. Not every configured provider receives every request. Research
          reports require a signed-in account; guests can run claim checks and citation scans within
          fair-use limits. Guest submissions are not saved to an account, but results may be cached
          temporarily and hashed visitor identifiers enforce existing fair-use limits. A matching
          fresh research result can be returned before any new search or model call.
        </p>
      </PageSection>
      <PageSection title="Model training">
        <p>
          <strong>
            We do not use your submitted text, documents or reports to train our own AI models.
          </strong>{" "}
          Third-party AI providers process your content under their own policies, which may differ.
        </p>
      </PageSection>
      <PageSection title="Information collected">
        <p>
          Account details such as email, optional display name and avatar; questions, uploaded
          document text and saved reports; usage counts, timestamps and share-link settings; support
          correspondence; and technical data such as IP address, browser information and a hashed
          visitor identifier used to enforce guest limits. When you subscribe, we store your
          subscription status, plan, billing period and provider identifiers, but not your card
          number. Voice recognition uses your browser’s native feature and audio is not sent to our
          servers.
        </p>
      </PageSection>
      <PageSection title="Why and on what basis">
        <p>
          We process account details, submitted content, saved reports and subscription state to
          provide the service you request and fulfill our contract with you. We process usage and
          technical identifiers to enforce plan limits, prevent abuse and maintain security under
          our legitimate interests. We respond to support requests under our contractual and
          legitimate interests and keep records where legally required. We do not use your uploaded
          material to train our own AI models; third-party provider policies may differ.
        </p>
      </PageSection>
      <PageSection title="Who receives information">
        <p>
          Questions and extracted document text may be processed by the AI providers, and search
          terms by the search and data services, listed under “AI and search processors” below.
          Lovable Cloud hosts account and report data. Paddle.com is our reseller and Merchant of
          Record and processes orders, subscription management, payments, taxes, invoicing and
          refunds under its own notices. We may disclose information to professional advisers or
          authorities where required by law. Do not submit confidential or sensitive personal
          information to research tools.
        </p>
      </PageSection>
      <PageSection title="AI and search processors">
        <p>
          Depending on availability, submitted text and retrieved excerpts may be processed by these
          AI providers: DeepInfra, Cerebras, SambaNova, NVIDIA, Groq, Google Gemini, Mistral,
          DeepSeek, Alibaba DashScope, GitHub Models and OpenRouter, and, when enabled, the Lovable
          AI Gateway as an optional fallback that routes requests to Google or OpenAI models. Search
          terms may go to these search and data services, depending on the tool and on which
          services are configured: Tavily (including site-limited Quora and Reddit searches used
          only as low-weight community context), Brave Search, You.com, a SearXNG instance, GDELT,
          DuckDuckGo, Wikipedia, Wikidata, Crossref, OpenAlex, PubMed, Europe PMC, Semantic Scholar,
          Stack Exchange, the Internet Archive's Wayback Machine, World Bank Open Data, SEC EDGAR
          and the Google Fact Check Tools API. Each provider handles data under its own terms; we do
          not permit our own use of your prompts or outputs for model training.
        </p>
      </PageSection>
      <PageSection title="Usage analytics">
        <p>
          Google Analytics and PostHog load only after you click “Accept analytics”. You can change
          or withdraw your choice at any time via “Cookie settings” in the footer. Global Privacy
          Control (GPC) is treated as a refusal unless you explicitly opt in there. Without
          acceptance, neither service loads or sends analytics requests. We use PostHog to measure
          page views, clicks, time on pages and exit points. PostHog receives browser/device
          information and an anonymous browser identifier stored locally. Tracking masks page text
          and element attributes and removes URL query strings, hashes and private report
          identifiers. We do not identify analytics visitors by account, record sessions, or send
          research input or report content through analytics. You can block analytics with your
          browser controls; clearing browser storage resets its identifier. PostHog processes these
          events in the United States for this project.
        </p>
        <p className="mt-3">
          We also use Google Analytics (Google LLC) to count page views. After acceptance, it loads
          in your browser and sends a page-view event for each page you visit, with the path only:
          query strings and hashes are removed, report, fact-check and resource identifiers are
          replaced with placeholders, the page title is sent as “Verfiai” and the referrer is left
          empty. Google Signals and ad-personalisation signals are turned off. Google Analytics sets
          its own first-party cookies (such as _ga) holding a random browser identifier, and Google
          receives your IP address and browser/device information under its own terms. You can also
          block analytics with your browser or extension controls. Withdrawal disables further
          tracking and removes accessible analytics cookies and browser-storage identifiers;
          requests already sent cannot be recalled.
        </p>
      </PageSection>
      <PageSection title="Data export and deletion">
        <p>
          You can copy, download (Word, Markdown, PDF) and delete each saved report yourself in My
          reports. To export or delete all account data, or close your account, email{" "}
          <a
            href="mailto:hello@verfiai.app?subject=Privacy%20request"
            className="text-brand underline"
          >
            hello@verfiai.app
          </a>{" "}
          with the subject “Privacy request”. We respond within 30 days.
        </p>
      </PageSection>
      <PageSection title="GDPR and CCPA contact">
        <p>
          EU/UK residents (GDPR) and California residents (CCPA/CPRA) can exercise their rights by
          emailing{" "}
          <a
            href="mailto:hello@verfiai.app?subject=Privacy%20request"
            className="text-brand underline"
          >
            hello@verfiai.app
          </a>
          . We do not sell or share personal information for cross-context behavioural advertising.
          You may also complain to your local data protection authority.
        </p>
      </PageSection>
      <PageSection title="Community waitlist">
        <p>
          If you choose to join the future Pro and Teams waitlist, we store your email address,
          consent version and signup date in Lovable Cloud. With your consent, we use it only for
          updates about these future features. Joining does not create a paid subscription. We keep
          your signup until you withdraw consent or the waitlist closes. Email hello@verfiai.app to
          withdraw consent or request deletion. A hashed IP identifier and request count are also
          stored to prevent signup abuse; your email is not publicly visible.
        </p>
      </PageSection>
      <PageSection title="Caching, freshness and retention">
        <p>
          Signed-in saved reports remain until you delete them from My reports. Research reuse is
          scoped to your account or hashed guest identity, exact request, language and scoring
          settings; it does not let another account retrieve your report. New or rarely repeated
          research results are considered fresh for 24 hours. Results used at least three times
          while fresh are reusable for seven days from their original creation, not seven days from
          each visit. On exhausted AI providers, a matching result up to thirty days old may be
          returned with its original date and an older-result notice. Without a matching answer,
          research and claim tools can show source links only, with no measured verdict.
          Search/model provider caches generally use 24-hour freshness, generated report caches
          seven days and citation metadata thirty days; server configuration may alter
          provider-cache freshness. Private verification response freshness remains 24 hours.
        </p>
        <p className="mt-3">
          Freshness limits govern reuse, not guaranteed physical deletion: provider and research
          cache rows may remain after they stop qualifying for reuse. Private verification responses
          are removed opportunistically after expiry. Monthly usage records and guest-limit
          identifiers may remain for quota enforcement and abuse prevention. Account, subscription
          and support records are kept while necessary to provide the service or meet legal
          obligations. Contact us to request deletion of submitted material or cached results.
          Deleting a saved report does not automatically remove its temporary cache entries or
          records Paddle must retain for payments or tax.
        </p>
      </PageSection>
      <PageSection title="Your choices and rights">
        <p>
          You can access and delete saved reports in My reports, and turn off a share link there.
          Anyone with an active share link can read that report. Depending on your location, you may
          request access, correction, deletion, restriction, portability or objection to processing,
          or withdraw consent where applicable. To request an account-data export or deletion, email{" "}
          <a className="text-brand underline" href="mailto:hello@verfiai.app">
            hello@verfiai.app
          </a>
          . If UK or EEA law applies, you may complain to a supervisory authority; we aim to respond
          to rights requests within one month, subject to lawful extensions. Legal retention
          obligations can limit deletion requests.
        </p>
      </PageSection>
      <PageSection title="Security, transfers and browser storage">
        <p>
          We use access controls and encrypted connections to protect data, but no internet system
          is completely secure. Providers may process data outside your country, including outside
          the UK or EEA. Where required, transfers rely on applicable safeguards such as adequacy
          decisions or standard contractual clauses. Essential session storage keeps you signed in;
          language preferences are stored in your browser and reflected in the page URL. We do not
          currently use marketing or advertising cookies in the app. A strictly necessary
          browser-storage record saves your accepted or rejected choice, policy version and
          timestamp for twelve months; we ask again when it expires or the consent policy version
          changes. Closing the banner without choosing does not grant consent. GPC is treated as
          refusal; you can explicitly opt in through “Cookie settings”. Analytics load only after
          acceptance, and you can withdraw through that footer control at any time. Analytics
          identifiers are used only for usage measurement: PostHog stores one in local storage, and
          Google Analytics sets first-party cookies (such as _ga). You can clear browser storage in
          your browser settings, though doing so may sign you out or reset preferences.
        </p>
        <p className="mt-3">
          For purchases, see our{" "}
          <Link to="/terms" className="text-brand underline">
            Terms
          </Link>{" "}
          and{" "}
          <Link to="/refunds" className="text-brand underline">
            Refund Policy
          </Link>
          .
        </p>
      </PageSection>
    </ContentPage>
  );
}
