import { createFileRoute } from "@tanstack/react-router";
import { ContentPage, PageSection } from "@/components/verifai/ContentPage";
import { FreeWebsitesDirectory } from "@/components/verifai/FreeWebsitesDirectory";
import { toolHead } from "@/lib/tools/tool-head";

export const Route = createFileRoute("/free-websites")({
  head: () =>
    toolHead({
      path: "/free-websites",
      name: "Free Websites Directory",
      title: "Free Websites for Researchers, Writers & Professionals | Verfiai",
      description:
        "A curated directory of free and free-tier websites for academic research, large file sharing, writing, data, verification and professional work.",
    }),
  component: Page,
});

function Page() {
  return (
    <ContentPage
      title="Free websites & essential services"
      intro="A practical directory of useful free websites for academics, scholars, researchers, writers, journalists, students and professionals. Find large-file sharing, research databases, writing tools, open data and verification services."
    >
      <FreeWebsitesDirectory />
      <PageSection title="How this directory fits Verfiai's policy">
        <p>
          Verfiai's own tools are designed to be transparent about what runs locally and what
          contacts an external source. This directory follows the same principle: it links directly
          to independent providers. Verfiai does not proxy their services, host uploaded files,
          embed their applications or claim that every linked service is completely free.
        </p>
      </PageSection>
    </ContentPage>
  );
}
