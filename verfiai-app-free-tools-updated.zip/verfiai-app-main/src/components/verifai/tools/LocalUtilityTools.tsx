import { useMemo, useState } from "react";

type UtilitySlug =
  | "json-formatter"
  | "uuid-generator"
  | "reference-deduplicator"
  | "identifier-extractor";

const areaClass =
  "min-h-44 w-full rounded-lg border border-border bg-background p-3 font-mono text-sm focus-visible:outline-2 focus-visible:outline-ring";
const buttonClass =
  "inline-flex min-h-11 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50";
const secondaryClass =
  "inline-flex min-h-11 items-center justify-center rounded-md border border-border px-4 py-2 text-sm font-semibold hover:bg-muted disabled:opacity-50";

function downloadText(filename: string, content: string, type = "text/plain;charset=utf-8") {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function makeUuid() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

type ReferenceRecord = { raw: string; key: string };

function normalizeTitle(value: string) {
  return value
    .toLowerCase()
    .replace(/<[^>]*>/g, " ")
    .replace(/[{}\\]/g, " ")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function extractDoi(value: string) {
  return (
    value.match(/10\.\d{4,9}\/[\w.()/:;-]+/i)?.[0]?.replace(/[.,;:)\]}]+$/, "").toLowerCase() ??
    ""
  );
}

function deduplicateReferences(source: string) {
  const trimmed = source.trim();
  let records: ReferenceRecord[] = [];
  let format = "Plain text";
  if (!trimmed) return { records, format, removed: 0 };

  if (/^\s*@\w+\s*[({]/m.test(trimmed)) {
    format = "BibTeX";
    const starts = [...trimmed.matchAll(/@\w+\s*[({]/g)].map((match) => match.index ?? 0);
    records = starts.map((start, index) => {
      const raw = trimmed.slice(start, starts[index + 1] ?? trimmed.length).trim();
      const doi = extractDoi(raw);
      const title = raw.match(/\btitle\s*=\s*[{"']([\s\S]*?)[}"']/i)?.[1] ?? "";
      const titleKey = normalizeTitle(title);
      return { raw, key: doi || titleKey || normalizeTitle(raw) };
    });
  } else if (/^\s*TY\s+-/m.test(trimmed)) {
    format = "RIS";
    const blocks = trimmed
      .split(/(?=^TY\s+-)/m)
      .map((item) => item.trim())
      .filter(Boolean);
    records = blocks.map((raw) => {
      const doi = extractDoi(raw.match(/^DO\s+-\s*(.+)$/im)?.[1] ?? raw);
      const title = raw.match(/^(?:TI|T1)\s+-\s*(.+)$/im)?.[1] ?? "";
      const titleKey = normalizeTitle(title);
      return { raw, key: doi || titleKey || normalizeTitle(raw) };
    });
  } else {
    records = trimmed
      .split(/\r?\n/)
      .map((raw) => raw.trim())
      .filter(Boolean)
      .map((raw) => {
        const doi = extractDoi(raw);
        return { raw, key: doi || normalizeTitle(raw) };
      });
  }

  const seen = new Set<string>();
  const unique: ReferenceRecord[] = [];
  for (const record of records) {
    const key = record.key || normalizeTitle(record.raw);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    unique.push(record);
  }
  return { records: unique, format, removed: records.length - unique.length };
}

function extractIdentifiers(source: string) {
  const doi = [...source.matchAll(/\b10\.\d{4,9}\/[\w.()/:;-]+/gi)].map((match) =>
    (match[0] ?? "").replace(/[.,;:)\]}]+$/, ""),
  );
  const orcid = [...source.matchAll(/\b\d{4}-\d{4}-\d{4}-\d{3}[\dX]\b/gi)].map(
    (match) => match[0] ?? "",
  );
  const pmid = [...source.matchAll(/\bPMID\s*:?\s*(\d{6,9})\b|\/pubmed\/(\d{6,9})\b/gi)]
    .map((match) => match[1] ?? match[2])
    .filter((value): value is string => typeof value === "string" && value.length > 0);
  const isbn = [...source.matchAll(/\bISBN(?:-1[03])?\s*:?\s*((?:97[89][ -]?)?(?:\d[ -]?){9}[\dX])\b/gi)]
    .map((match) => (match[1] ?? "").replace(/[ -]/g, ""))
    .filter(Boolean);
  const unique = (values: string[]) => [...new Set(values)];
  return { DOI: unique(doi), ORCID: unique(orcid), PMID: unique(pmid), ISBN: unique(isbn) };
}

export function LocalUtilityTools({ slug }: { slug: UtilitySlug }) {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const [count, setCount] = useState("10");
  const [uuids, setUuids] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);
  const references = useMemo(
    () => (slug === "reference-deduplicator" ? deduplicateReferences(input) : null),
    [input, slug],
  );
  const identifiers = useMemo(
    () => (slug === "identifier-extractor" ? extractIdentifiers(input) : null),
    [input, slug],
  );

  async function copy(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setError("Clipboard access is unavailable. Select and copy the result manually.");
    }
  }

  if (slug === "json-formatter") {
    const run = (mode: "pretty" | "minify") => {
      setError("");
      setOutput("");
      try {
        const parsed: unknown = JSON.parse(input);
        setOutput(mode === "pretty" ? JSON.stringify(parsed, null, 2) : JSON.stringify(parsed));
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : "Invalid JSON.");
      }
    };

    return (
      <div className="space-y-4">
        <label className="block space-y-2">
          <span className="text-sm font-semibold">Paste JSON</span>
          <textarea
            className={areaClass}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder={'{\n  "title": "Example",\n  "verified": true\n}'}
            spellCheck={false}
          />
        </label>
        <div className="flex flex-wrap gap-2">
          <button className={buttonClass} onClick={() => run("pretty")} disabled={!input.trim()}>
            Format & validate
          </button>
          <button className={secondaryClass} onClick={() => run("minify")} disabled={!input.trim()}>
            Minify JSON
          </button>
          <button
            className={secondaryClass}
            onClick={() => {
              setInput("");
              setOutput("");
              setError("");
            }}
          >
            Clear
          </button>
        </div>
        {error && (
          <p role="alert" className="rounded-md border border-destructive/40 p-3 text-sm text-destructive">
            JSON error: {error}
          </p>
        )}
        {output && (
          <section className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-semibold">Valid JSON output</h3>
              <div className="flex gap-2">
                <button className={secondaryClass} onClick={() => void copy(output)}>
                  Copy
                </button>
                <button
                  className={secondaryClass}
                  onClick={() => downloadText("formatted.json", output, "application/json")}
                >
                  Download
                </button>
              </div>
            </div>
            <pre className="max-h-[32rem] overflow-auto whitespace-pre-wrap break-words rounded-md border border-border bg-muted p-3 text-xs">
              {output}
            </pre>
          </section>
        )}
        <p className="text-xs text-muted-foreground">
          Runs entirely in this browser. The JSON is not uploaded to Verfiai or an external API.
        </p>
      </div>
    );
  }

  if (slug === "uuid-generator") {
    return (
      <div className="space-y-4">
        <label className="block max-w-xs space-y-2">
          <span className="text-sm font-semibold">Number of UUIDs (1–100)</span>
          <input
            className="min-h-11 w-full rounded-md border border-border bg-background px-3"
            type="number"
            min="1"
            max="100"
            value={count}
            onChange={(event) => setCount(event.target.value)}
          />
        </label>
        <div className="flex flex-wrap gap-2">
          <button
            className={buttonClass}
            onClick={() => {
              const amount = Math.max(1, Math.min(100, Number(count) || 1));
              setUuids(Array.from({ length: amount }, makeUuid));
            }}
          >
            Generate UUIDs
          </button>
          <button
            className={secondaryClass}
            disabled={!uuids.length}
            onClick={() => void copy(uuids.join("\n"))}
          >
            Copy all
          </button>
          <button
            className={secondaryClass}
            disabled={!uuids.length}
            onClick={() => downloadText("verfiai-uuids.txt", uuids.join("\n"))}
          >
            Download
          </button>
        </div>
        {uuids.length > 0 && (
          <div className="max-h-96 space-y-2 overflow-auto rounded-md border border-border p-3">
            {uuids.map((uuid) => (
              <code key={uuid} className="block break-all text-sm">
                {uuid}
              </code>
            ))}
          </div>
        )}
        {copied && <p role="status" className="text-sm text-muted-foreground">Copied.</p>}
        <p className="text-xs text-muted-foreground">
          Uses the browser's cryptographically secure random generator. UUIDs are generated locally;
          no request is sent.
        </p>
      </div>
    );
  }

  if (slug === "reference-deduplicator") {
    const cleaned = references?.records.map((record) => record.raw).join("\n\n") ?? "";
    return (
      <div className="space-y-4">
        <label className="block space-y-2">
          <span className="text-sm font-semibold">Paste a bibliography, RIS export, or BibTeX entries</span>
          <textarea
            className={`${areaClass} min-h-64`}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder="Paste references here. Supported: one reference per line, RIS records, or BibTeX entries."
          />
        </label>
        <div className="flex flex-wrap gap-2">
          <button className={buttonClass} disabled={!input.trim()} onClick={() => setOutput(cleaned)}>
            Prepare deduplicated list
          </button>
          <button
            className={secondaryClass}
            onClick={() => {
              setInput("");
              setOutput("");
            }}
          >
            Clear
          </button>
        </div>
        {input.trim() && (
          <p className="text-sm text-muted-foreground">
            Detected format: {references?.format}. {references?.records.length} unique record(s);{" "}
            {references?.removed} duplicate(s) removed.
          </p>
        )}
        {output && (
          <section className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-semibold">Cleaned references</h3>
              <div className="flex gap-2">
                <button className={secondaryClass} onClick={() => void copy(output)}>
                  Copy
                </button>
                <button
                  className={secondaryClass}
                  onClick={() => downloadText("deduplicated-references.txt", output)}
                >
                  Download
                </button>
              </div>
            </div>
            <pre className="max-h-[32rem] overflow-auto whitespace-pre-wrap break-words rounded-md border border-border bg-muted p-3 text-xs">
              {output}
            </pre>
          </section>
        )}
        <p className="text-xs text-muted-foreground">
          Deduplication uses DOI where available, otherwise normalized titles or lines. It is a
          screening aid, not a full bibliographic parser; inspect near-duplicates manually.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <label className="block space-y-2">
        <span className="text-sm font-semibold">Paste text, references, or a document excerpt</span>
        <textarea
          className={`${areaClass} min-h-64`}
          value={input}
          onChange={(event) => setInput(event.target.value)}
          placeholder="Paste text containing DOI, ORCID, PMID or ISBN identifiers…"
        />
      </label>
      <div className="flex flex-wrap gap-2">
        <button
          className={buttonClass}
          disabled={!input.trim()}
          onClick={() => setOutput(JSON.stringify(identifiers, null, 2))}
        >
          Extract identifiers
        </button>
        <button
          className={secondaryClass}
          onClick={() => {
            setInput("");
            setOutput("");
          }}
        >
          Clear
        </button>
      </div>
      {output && (
        <section className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-semibold">Extracted identifiers</h3>
            <button className={secondaryClass} onClick={() => void copy(output)}>
              Copy JSON
            </button>
          </div>
          <pre className="overflow-auto rounded-md border border-border bg-muted p-3 text-xs">
            {output}
          </pre>
        </section>
      )}
      <p className="text-xs text-muted-foreground">
        Extraction runs locally. The patterns identify candidate identifiers; verify them with the
        relevant registry before citing.
      </p>
    </div>
  );
}
