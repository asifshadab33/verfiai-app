import { useState } from "react";
import { AlertCircle, Loader2, Shield } from "lucide-react";
import { checkDomainAge } from "@/lib/tools/domain-age";

type Result = Awaited<ReturnType<typeof checkDomainAge>>;

export default function DomainAgeChecker() {
  const [domain, setDomain] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState("");

  const handleCheck = async () => {
    if (!domain.trim()) return;
    setLoading(true);
    setError("");
    setResult(null);
    try {
      setResult(await checkDomainAge(domain));
    } catch (reason) {
      setError(
        reason instanceof Error
          ? reason.message
          : "Could not retrieve the public RDAP record.",
      );
    } finally {
      setLoading(false);
    }
  };

  const registration = result?.events?.find(
    (event) => event.eventAction?.toLowerCase() === "registration",
  )?.eventDate;
  const registrationDate = registration ? new Date(registration) : null;
  const registrationDateText =
    registrationDate && !Number.isNaN(registrationDate.getTime())
      ? registrationDate.toLocaleDateString()
      : null;
  const isRecent =
    registrationDateText && registrationDate
      ? registrationDate.getTime() >= Date.now() - 365 * 24 * 60 * 60 * 1000
      : false;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-2 sm:flex-row">
        <label htmlFor="domain-age-input" className="flex-1 space-y-2 text-sm font-semibold">
          Domain name
          <input
            id="domain-age-input"
            type="text"
            placeholder="example.com"
            className="min-h-11 w-full rounded-md border border-border bg-background px-3 font-normal"
            value={domain}
            onChange={(event) => setDomain(event.target.value)}
            onKeyDown={(event) => event.key === "Enter" && void handleCheck()}
          />
        </label>
        <button
          type="button"
          onClick={() => void handleCheck()}
          disabled={loading || !domain.trim()}
          className="inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 font-semibold text-primary-foreground disabled:opacity-50"
        >
          {loading ? <Loader2 className="size-4 animate-spin" /> : "Check domain"}
        </button>
      </div>
      {error && (
        <div role="alert" className="flex items-start gap-2 rounded-lg border border-destructive/40 p-3 text-sm">
          <AlertCircle className="mt-0.5 size-4 shrink-0" />
          {error}
        </div>
      )}
      {result && (
        <div className="space-y-2 rounded-lg border border-border p-4">
          <h2 className="flex items-center gap-2 font-bold">
            <Shield className="size-4" /> Public domain registration record
          </h2>
          <p className="text-sm">
            <strong>{result.normalizedDomain}</strong>
          </p>
          <p className="text-sm">
            {registrationDateText ? (
              <>
                Registration date: <strong>{registrationDateText}</strong>
              </>
            ) : (
              "The registry did not publish a registration date in its RDAP response."
            )}
          </p>
          {isRecent && (
            <p className="text-sm font-medium text-amber-700">
              This domain appears to have been registered within the last 12 months. Treat this as
              one clue, not proof of risk.
            </p>
          )}
          <p className="text-xs text-muted-foreground">
            Registry status: {result.status?.join(", ") || "Not provided"}
          </p>
        </div>
      )}
      <p className="text-xs text-muted-foreground">
        Looks up the IANA RDAP bootstrap list and then queries the appropriate public domain
        registry directly from your browser. Some registries limit browser access or omit
        registration dates.
      </p>
    </div>
  );
}
