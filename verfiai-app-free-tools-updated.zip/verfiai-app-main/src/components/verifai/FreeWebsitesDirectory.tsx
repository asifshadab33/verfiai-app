import { useMemo, useState } from "react";
import { FREE_WEBSITE_CATEGORIES } from "@/data/freeWebsites";

export function FreeWebsitesDirectory() {
  const [query, setQuery] = useState("");
  const total = FREE_WEBSITE_CATEGORIES.reduce((sum, category) => sum + category.sites.length, 0);
  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return FREE_WEBSITE_CATEGORIES;
    return FREE_WEBSITE_CATEGORIES.map((category) => ({
      ...category,
      sites: category.sites.filter((site) =>
        [site.name, site.description, site.audience, site.note, category.title]
          .filter(Boolean)
          .join(" ")
          .toLowerCase()
          .includes(needle),
      ),
    })).filter((category) => category.sites.length > 0);
  }, [query]);
  const visibleCount = filtered.reduce((sum, category) => sum + category.sites.length, 0);

  return (
    <div className="space-y-8">
      <div className="rounded-xl border border-border bg-muted/40 p-5">
        <p className="font-semibold">A curated directory of {total} useful external services</p>
        <p className="mt-2 text-sm leading-6 text-muted-foreground">
          Find free or free-tier websites for research, writing, file sharing, data, verification
          and everyday professional work. Verfiai does not host these services or send your content
          to them automatically.
        </p>
        <label className="mt-4 block space-y-2">
          <span className="text-sm font-semibold">Search the directory</span>
          <input
            className="min-h-11 w-full rounded-md border border-border bg-background px-3"
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search e.g. large files, DOI, writing, datasets…"
          />
        </label>
        <p className="mt-2 text-xs text-muted-foreground">
          Showing {visibleCount} services in {filtered.length} categories.
        </p>
      </div>

      {filtered.map((category) => (
        <section key={category.id} id={category.id} className="scroll-mt-24 space-y-3">
          <div>
            <h2 className="font-display text-xl font-bold">{category.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{category.intro}</p>
          </div>
          <ul className="grid gap-3 sm:grid-cols-2">
            {category.sites.map((site) => (
              <li key={site.url} className="flex min-w-0 flex-col rounded-lg border border-border p-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <h3 className="font-semibold">{site.name}</h3>
                  <span className="rounded-full bg-muted px-2 py-1 text-xs text-muted-foreground">
                    {site.audience}
                  </span>
                </div>
                <p className="mt-2 flex-1 text-sm leading-6 text-muted-foreground">
                  {site.description}
                </p>
                {site.note && (
                  <p className="mt-2 text-xs leading-5 text-muted-foreground">Note: {site.note}</p>
                )}
                <a
                  className="mt-3 inline-flex min-h-11 items-center font-semibold text-brand underline underline-offset-4"
                  href={site.url}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Visit official website ↗
                </a>
              </li>
            ))}
          </ul>
        </section>
      ))}

      {filtered.length === 0 && (
        <p className="rounded-lg border border-dashed border-border p-6 text-sm text-muted-foreground">
          No services match that search. Try a broader keyword.
        </p>
      )}

      <div className="rounded-lg border border-border p-4 text-sm leading-6 text-muted-foreground">
        <strong className="text-foreground">Privacy and safety:</strong> These are independent
        third-party services, not Verfiai products. Free plans, file limits, availability and
        privacy terms can change. Before uploading, check the provider's terms, sharing permissions,
        retention and licence. Do not upload confidential client files, unpublished research,
        personal data, interview transcripts, medical information or legally protected material
        unless you have permission and an appropriate agreement. For sensitive files, prefer
        local/offline tools or institution-approved services. Verfiai does not endorse or guarantee
        any external provider.
      </div>
    </div>
  );
}
