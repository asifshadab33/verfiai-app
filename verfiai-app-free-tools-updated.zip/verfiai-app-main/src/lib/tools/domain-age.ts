type RdapBootstrap = { services?: [string[], string[]][] };
type RdapDomain = {
  ldhName?: string;
  events?: { eventAction?: string; eventDate?: string }[];
  status?: string[];
  nameservers?: { ldhName?: string }[];
};

let bootstrapPromise: Promise<RdapBootstrap> | null = null;

function normalizeDomain(value: string) {
  const withoutScheme = value.trim().replace(/^https?:\/\//i, "");
  const candidate = (withoutScheme.split(/[/?#]/, 1)[0] ?? "")
    .replace(/:\d+$/, "")
    .replace(/\.$/, "");
  if (!candidate || candidate.length > 253 || candidate.includes("@")) {
    throw new Error("Enter a valid domain name, such as example.org.");
  }

  let hostname: string;
  try {
    hostname = new URL(`https://${candidate}`).hostname.toLowerCase();
  } catch {
    throw new Error("Enter a valid domain name, such as example.org.");
  }

  const invalidLabel = hostname
    .split(".")
    .some(
      (label) =>
        !label ||
        label.length > 63 ||
        !/^[a-z0-9-]+$/i.test(label) ||
        label.startsWith("-") ||
        label.endsWith("-"),
    );
  if (!hostname.includes(".") || invalidLabel) {
    throw new Error("Enter a valid registered domain name.");
  }
  return hostname;
}

async function getBootstrap() {
  if (!bootstrapPromise) {
    bootstrapPromise = fetch("https://data.iana.org/rdap/dns.json", {
      headers: { Accept: "application/json" },
    })
      .then(async (response) => {
        if (!response.ok) {
          throw new Error("The IANA RDAP registry list is temporarily unavailable.");
        }
        return (await response.json()) as RdapBootstrap;
      })
      .catch((error) => {
        bootstrapPromise = null;
        throw error;
      });
  }
  return bootstrapPromise;
}

export async function checkDomainAge(
  input: string,
): Promise<RdapDomain & { normalizedDomain: string }> {
  const domain = normalizeDomain(input);
  const bootstrap = await getBootstrap();
  const labels = domain.split(".");
  const candidates: { suffix: string; base: string }[] = [];

  for (const [suffixes, urls] of bootstrap.services ?? []) {
    for (const suffix of suffixes) {
      if ((domain === suffix || domain.endsWith(`.${suffix}`)) && urls[0]) {
        candidates.push({ suffix, base: urls[0] });
      }
    }
  }

  candidates.sort((a, b) => b.suffix.length - a.suffix.length);
  const base = candidates[0]?.base;
  if (!base) {
    throw new Error(`No RDAP registry is listed for the .${labels[labels.length - 1]} domain extension.`);
  }

  const response = await fetch(
    `${base.replace(/\/$/, "")}/domain/${encodeURIComponent(domain)}`,
    { headers: { Accept: "application/rdap+json, application/json" } },
  );
  if (response.status === 404) {
    throw new Error("No public RDAP registration record was found for this domain.");
  }
  if (!response.ok) {
    throw new Error(`The domain registry returned HTTP ${response.status}. Try again later.`);
  }
  const data = (await response.json()) as RdapDomain;
  return { ...data, normalizedDomain: domain };
}
