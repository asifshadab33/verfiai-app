export type FreeWebsite = { name: string; url: string; description: string; audience: string; note?: string };
export type FreeWebsiteCategory = { id: string; title: string; intro: string; sites: FreeWebsite[] };

// Curated external destinations only: no embeds, proxying, file uploads, or API calls from Verfiai.
export const FREE_WEBSITE_CATEGORIES: FreeWebsiteCategory[] = [
  {
    "id": "large-files",
    "title": "Send large files & share storage",
    "intro": "For sending files that are too large for email, or keeping files in a shared cloud folder.",
    "sites": [
      {
        "name": "SwissTransfer",
        "url": "https://www.swisstransfer.com/",
        "description": "Temporary file transfers; provider currently advertises up to 50 GB per transfer without a paid subscription.",
        "audience": "Large one-off transfers",
        "note": "Transfer links expire. Check regional availability and current limits."
      },
      {
        "name": "Filemail",
        "url": "https://www.filemail.com/",
        "description": "Temporary file sharing; its free no-registration service currently advertises transfers up to 5 GB.",
        "audience": "Large one-off transfers",
        "note": "Free use is limited to two transfers per 24 hours; files are retained for up to seven days."
      },
      {
        "name": "WeTransfer",
        "url": "https://wetransfer.com/",
        "description": "Simple temporary file delivery with a free account option.",
        "audience": "Occasional sharing",
        "note": "Current free plan: up to 10 transfers or 3 GB total in a rolling 30-day period; links last up to three days."
      },
      {
        "name": "TransferNow",
        "url": "https://www.transfernow.net/",
        "description": "Temporary file transfer with free and paid options.",
        "audience": "One-off sharing",
        "note": "Check the current free size and retention limits before uploading."
      },
      {
        "name": "Smash",
        "url": "https://fromsmash.com/",
        "description": "Temporary large-file transfer service with a free option.",
        "audience": "Media and project files",
        "note": "Speed and queue conditions may apply to larger transfers."
      },
      {
        "name": "Google Drive",
        "url": "https://drive.google.com/",
        "description": "Cloud storage, document collaboration and shareable folders.",
        "audience": "Ongoing collaboration",
        "note": "Free storage is shared across Google services; sharing permissions need careful review."
      },
      {
        "name": "Microsoft OneDrive",
        "url": "https://onedrive.live.com/",
        "description": "Cloud storage and file sharing with a Microsoft account.",
        "audience": "Ongoing collaboration",
        "note": "Free storage is limited; check the current account allowance."
      },
      {
        "name": "Dropbox Basic",
        "url": "https://www.dropbox.com/basic",
        "description": "Cloud file storage and shared links.",
        "audience": "Small shared folders",
        "note": "The free plan has a small storage allowance; not a long-term archive for large projects."
      },
      {
        "name": "Proton Drive",
        "url": "https://drive.proton.me/",
        "description": "Privacy-focused cloud storage and file sharing.",
        "audience": "Privacy-conscious sharing",
        "note": "Free storage and sharing features are limited; review the provider's current plan."
      }
    ]
  },
  {
    "id": "academic-search",
    "title": "Academic search & scholarly literature",
    "intro": "Search papers, authors, journals, preprints and citation metadata. Free discovery does not guarantee free full text.",
    "sites": [
      {
        "name": "Google Scholar",
        "url": "https://scholar.google.com/",
        "description": "Broad scholarly search across articles, books, theses and citations.",
        "audience": "All disciplines",
        "note": "Coverage and citation counts can be incomplete or duplicated."
      },
      {
        "name": "OpenAlex",
        "url": "https://openalex.org/",
        "description": "Open catalogue of scholarly works, authors, institutions and topics.",
        "audience": "Research discovery and bibliometrics"
      },
      {
        "name": "Semantic Scholar",
        "url": "https://www.semanticscholar.org/",
        "description": "Scholarly search with citation and related-paper discovery.",
        "audience": "Research discovery"
      },
      {
        "name": "Crossref Search",
        "url": "https://search.crossref.org/",
        "description": "Search publication metadata and DOI records.",
        "audience": "Citation verification"
      },
      {
        "name": "PubMed",
        "url": "https://pubmed.ncbi.nlm.nih.gov/",
        "description": "Biomedical and life-sciences literature citations and abstracts.",
        "audience": "Medicine and life sciences"
      },
      {
        "name": "PubMed Central",
        "url": "https://pmc.ncbi.nlm.nih.gov/",
        "description": "Free full-text archive of biomedical and life-sciences articles.",
        "audience": "Biomedical full text"
      },
      {
        "name": "Europe PMC",
        "url": "https://europepmc.org/",
        "description": "Life-sciences literature, preprints and open full text.",
        "audience": "Life sciences"
      },
      {
        "name": "arXiv",
        "url": "https://arxiv.org/",
        "description": "Open preprint repository for physics, mathematics, computer science and related fields.",
        "audience": "STEM preprints",
        "note": "Preprints are not necessarily peer reviewed."
      },
      {
        "name": "Directory of Open Access Journals",
        "url": "https://doaj.org/",
        "description": "Directory of open-access journals and articles.",
        "audience": "Open-access publishing"
      },
      {
        "name": "CORE",
        "url": "https://core.ac.uk/",
        "description": "Discovery of open-access research outputs from repositories.",
        "audience": "Open-access papers"
      },
      {
        "name": "OpenAIRE Explore",
        "url": "https://explore.openaire.eu/",
        "description": "Discover publications, datasets, software and research projects.",
        "audience": "Open science"
      },
      {
        "name": "ERIC",
        "url": "https://eric.ed.gov/",
        "description": "Education research database and resources.",
        "audience": "Education"
      },
      {
        "name": "BASE",
        "url": "https://www.base-search.net/",
        "description": "Academic search engine focused on scholarly web resources.",
        "audience": "Repositories and theses"
      },
      {
        "name": "OATD",
        "url": "https://oatd.org/",
        "description": "Open access theses and dissertations discovery.",
        "audience": "Graduate research"
      },
      {
        "name": "RePEc",
        "url": "https://repec.org/",
        "description": "Research Papers in Economics: working papers, articles and author profiles.",
        "audience": "Economics"
      },
      {
        "name": "Google Dataset Search",
        "url": "https://datasetsearch.research.google.com/",
        "description": "Discover datasets hosted by publishers, repositories and public agencies.",
        "audience": "Research datasets"
      }
    ]
  },
  {
    "id": "reference-publishing",
    "title": "Reference management, researcher IDs & publishing",
    "intro": "Organize citations, manage research identity, collaborate and publish research outputs.",
    "sites": [
      {
        "name": "Zotero",
        "url": "https://www.zotero.org/",
        "description": "Free reference manager for collecting sources, organizing libraries and creating citations.",
        "audience": "Students, academics and writers",
        "note": "Local library use is free; online storage and group features have limits."
      },
      {
        "name": "ZoteroBib",
        "url": "https://zbib.org/",
        "description": "Create bibliographies quickly without installing reference-management software.",
        "audience": "Quick citations"
      },
      {
        "name": "ORCID",
        "url": "https://orcid.org/",
        "description": "Free persistent researcher identifier and profile.",
        "audience": "Researchers and scholars"
      },
      {
        "name": "Research Organization Registry",
        "url": "https://ror.org/",
        "description": "Open identifiers for research organizations.",
        "audience": "Institutional metadata"
      },
      {
        "name": "Zenodo",
        "url": "https://zenodo.org/",
        "description": "Repository for research papers, datasets, software and other research outputs.",
        "audience": "Research sharing",
        "note": "Review upload policies, licences and record visibility."
      },
      {
        "name": "Open Science Framework",
        "url": "https://osf.io/",
        "description": "Project spaces and collaboration tools for open research workflows.",
        "audience": "Research teams",
        "note": "Choose public or private project settings carefully."
      },
      {
        "name": "Figshare",
        "url": "https://figshare.com/",
        "description": "Share and discover research outputs and datasets.",
        "audience": "Research data",
        "note": "Free personal and institutional features vary."
      },
      {
        "name": "PRISMA",
        "url": "https://www.prisma-statement.org/",
        "description": "Reporting guideline and checklist for systematic reviews.",
        "audience": "Systematic reviews"
      },
      {
        "name": "EQUATOR Network",
        "url": "https://www.equator-network.org/",
        "description": "Reporting guidelines for health research studies.",
        "audience": "Health research"
      },
      {
        "name": "COPE",
        "url": "https://publicationethics.org/",
        "description": "Publication ethics guidance and resources.",
        "audience": "Editors and authors"
      }
    ]
  },
  {
    "id": "writing-office",
    "title": "Writing, editing & office productivity",
    "intro": "Writing, editing, document preparation and collaboration tools. Cloud editors may process your text on their servers.",
    "sites": [
      {
        "name": "LibreOffice",
        "url": "https://www.libreoffice.org/",
        "description": "Free, open-source desktop office suite for documents, spreadsheets and presentations.",
        "audience": "Offline office work",
        "note": "Desktop-first; files can stay on your device."
      },
      {
        "name": "LanguageTool",
        "url": "https://languagetool.org/",
        "description": "Spelling, grammar and style suggestions with a free tier.",
        "audience": "Writers and editors",
        "note": "Pasted text may be sent to the provider; avoid confidential material."
      },
      {
        "name": "Hemingway Editor",
        "url": "https://hemingwayapp.com/",
        "description": "Readability and sentence-complexity feedback.",
        "audience": "Clear writing",
        "note": "Use readability scores as guidance, not as a quality verdict."
      },
      {
        "name": "Google Docs",
        "url": "https://docs.google.com/",
        "description": "Browser-based document writing and collaboration.",
        "audience": "Collaborative writing",
        "note": "Review link-sharing permissions and account storage."
      },
      {
        "name": "Overleaf",
        "url": "https://www.overleaf.com/",
        "description": "Online LaTeX writing and collaboration for technical documents.",
        "audience": "Academic typesetting",
        "note": "Free plan has limits; check current terms."
      },
      {
        "name": "Typst",
        "url": "https://typst.app/",
        "description": "Modern typesetting and collaborative document authoring.",
        "audience": "Technical writing",
        "note": "Free features and account limits may change."
      },
      {
        "name": "Purdue OWL",
        "url": "https://owl.purdue.edu/",
        "description": "Free writing, citation and academic style guides.",
        "audience": "Academic writing"
      },
      {
        "name": "Excalidraw",
        "url": "https://excalidraw.com/",
        "description": "Quick hand-drawn diagrams and whiteboards.",
        "audience": "Teaching and planning",
        "note": "Check collaboration and storage settings before sharing sensitive diagrams."
      },
      {
        "name": "diagrams.net",
        "url": "https://app.diagrams.net/",
        "description": "Create flowcharts, system diagrams and process maps.",
        "audience": "Professionals and students",
        "note": "Supports local file workflows; choose storage location intentionally."
      },
      {
        "name": "Mermaid Live Editor",
        "url": "https://mermaid.live/",
        "description": "Create diagrams from text-based Mermaid syntax.",
        "audience": "Technical documentation"
      }
    ]
  },
  {
    "id": "data-statistics",
    "title": "Open data, statistics & public information",
    "intro": "Find public datasets and official statistics for evidence-based reporting and research.",
    "sites": [
      {
        "name": "Our World in Data",
        "url": "https://ourworldindata.org/",
        "description": "Research and visualizations on global challenges with linked sources.",
        "audience": "Public policy and research",
        "note": "Check the licence and original data source for each chart or dataset."
      },
      {
        "name": "World Bank Open Data",
        "url": "https://data.worldbank.org/",
        "description": "Development indicators and country-level datasets.",
        "audience": "Economics and policy"
      },
      {
        "name": "FRED",
        "url": "https://fred.stlouisfed.org/",
        "description": "Economic and financial time-series data from the Federal Reserve Bank of St. Louis.",
        "audience": "Economics and finance"
      },
      {
        "name": "OECD Data Explorer",
        "url": "https://data-explorer.oecd.org/",
        "description": "International statistics and policy indicators.",
        "audience": "Policy and economics"
      },
      {
        "name": "UN Data",
        "url": "https://data.un.org/",
        "description": "United Nations statistical databases.",
        "audience": "International statistics"
      },
      {
        "name": "Eurostat",
        "url": "https://ec.europa.eu/eurostat/",
        "description": "Official statistics from the European Union.",
        "audience": "European statistics"
      },
      {
        "name": "Data.gov",
        "url": "https://data.gov/",
        "description": "U.S. government open data catalogue.",
        "audience": "Public datasets"
      },
      {
        "name": "data.europa.eu",
        "url": "https://data.europa.eu/",
        "description": "European data portal for public-sector datasets.",
        "audience": "Public datasets"
      },
      {
        "name": "Kaggle Datasets",
        "url": "https://www.kaggle.com/datasets",
        "description": "Community datasets and notebooks for analysis and learning.",
        "audience": "Data science",
        "note": "Check dataset provenance, licence and collection method."
      }
    ]
  },
  {
    "id": "images-media",
    "title": "Images, media & reuse licences",
    "intro": "Find images and media with reusable licences. Always verify the licence on the individual asset page before reuse.",
    "sites": [
      {
        "name": "Openverse",
        "url": "https://openverse.org/",
        "description": "Search openly licensed images and audio across multiple sources.",
        "audience": "Creative Commons media",
        "note": "Verify the individual asset licence and attribution requirements."
      },
      {
        "name": "Wikimedia Commons",
        "url": "https://commons.wikimedia.org/",
        "description": "Media repository with file-level licensing information.",
        "audience": "Educational and editorial media",
        "note": "Each file has its own licence and attribution rules."
      },
      {
        "name": "Unsplash",
        "url": "https://unsplash.com/",
        "description": "Photographs available under the Unsplash licence.",
        "audience": "Web and editorial imagery",
        "note": "Review current licence terms and avoid implying endorsement."
      },
      {
        "name": "Pexels",
        "url": "https://www.pexels.com/",
        "description": "Free stock photos and videos under the Pexels licence.",
        "audience": "Web and presentations",
        "note": "Review current licence and restrictions before commercial use."
      },
      {
        "name": "Pixabay",
        "url": "https://pixabay.com/",
        "description": "Stock images, illustrations, music and video.",
        "audience": "Creative projects",
        "note": "Check the Content License and any third-party rights."
      }
    ]
  },
  {
    "id": "verification-security",
    "title": "Web verification, archives & security",
    "intro": "Independent tools that help inspect URLs, preserve web pages and check technical indicators. Results are clues, not proof.",
    "sites": [
      {
        "name": "Internet Archive Wayback Machine",
        "url": "https://web.archive.org/",
        "description": "Look for archived versions of web pages.",
        "audience": "Journalists and researchers",
        "note": "Not every page is archived; archived captures can be incomplete."
      },
      {
        "name": "Google Fact Check Explorer",
        "url": "https://toolbox.google.com/factcheck/explorer",
        "description": "Search fact-check articles published by participating organizations.",
        "audience": "Fact-checkers",
        "note": "No result does not mean a claim is true."
      },
      {
        "name": "TinEye",
        "url": "https://tineye.com/",
        "description": "Reverse image search to find copies and appearances of an image.",
        "audience": "Image verification",
        "note": "Uploading an image sends it to the external provider."
      },
      {
        "name": "Google Lens",
        "url": "https://lens.google/",
        "description": "Visual search for image matches and related context.",
        "audience": "Image research",
        "note": "Image searches are processed by Google."
      },
      {
        "name": "InVID-WeVerify",
        "url": "https://www.invid-project.eu/tools-and-services/invid-verification-plugin/",
        "description": "Video and image verification aids including keyframe workflows.",
        "audience": "Journalists and OSINT",
        "note": "Verification aids do not certify authenticity."
      },
      {
        "name": "VirusTotal",
        "url": "https://www.virustotal.com/",
        "description": "Check URLs, domains, hashes and files against security engines.",
        "audience": "Security review",
        "note": "Do not upload confidential or private files: submitted samples may be shared with security partners."
      },
      {
        "name": "urlscan.io",
        "url": "https://urlscan.io/",
        "description": "Inspect how a public website loads and what it connects to.",
        "audience": "Web security",
        "note": "Scans may be publicly visible depending on submission settings; never submit private URLs."
      },
      {
        "name": "Have I Been Pwned",
        "url": "https://haveibeenpwned.com/",
        "description": "Check whether an email address appears in known data breaches.",
        "audience": "Account security",
        "note": "Use the official site; never enter passwords into breach-checking sites."
      },
      {
        "name": "DNS over HTTPS (Cloudflare)",
        "url": "https://1.1.1.1/help",
        "description": "Check whether your connection is using Cloudflare's DNS resolver.",
        "audience": "Network troubleshooting"
      }
    ]
  },
  {
    "id": "pdf-conversion",
    "title": "PDF, document & file utilities",
    "intro": "Document utilities can be convenient, but online converters usually require uploading the document to another company.",
    "sites": [
      {
        "name": "PDF24 Tools",
        "url": "https://tools.pdf24.org/",
        "description": "Online PDF merge, split, compress, convert and edit tools.",
        "audience": "PDF workflows",
        "note": "Use its desktop tools for sensitive documents where possible; read the privacy notice for online processing."
      },
      {
        "name": "iLovePDF",
        "url": "https://www.ilovepdf.com/",
        "description": "Online PDF conversion, compression and editing utilities.",
        "audience": "PDF workflows",
        "note": "Free usage has limits; documents are uploaded to an external provider."
      },
      {
        "name": "Smallpdf",
        "url": "https://smallpdf.com/",
        "description": "Online PDF conversion and document tools.",
        "audience": "PDF workflows",
        "note": "Free usage has limits; do not upload confidential files without approval."
      },
      {
        "name": "CloudConvert",
        "url": "https://cloudconvert.com/",
        "description": "Online file conversion across many formats.",
        "audience": "File conversion",
        "note": "Free conversion allowance is limited; uploaded files are handled by an external service."
      },
      {
        "name": "CyberChef",
        "url": "https://gchq.github.io/CyberChef/",
        "description": "Browser-based data encoding, decoding, hashing and analysis recipes.",
        "audience": "Technical analysis",
        "note": "Many recipes run client-side in the browser; verify the page and recipe before processing sensitive data."
      },
      {
        "name": "JSONLint",
        "url": "https://jsonlint.com/",
        "description": "Validate JSON syntax with a simple online checker.",
        "audience": "Developers",
        "note": "Use Verfiai's local JSON formatter for confidential JSON instead of pasting it into a third-party site."
      }
    ]
  }
];
